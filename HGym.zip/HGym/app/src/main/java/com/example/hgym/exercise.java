package com.example.hgym;

public class exercise {
    protected String muscleGroup;
    protected String name;
    protected int levelOfDifficulty;

    public exercise()
    {

    }
    public exercise(String muscleGroup, String name, int levelOfDifficulty) {
        this.muscleGroup = muscleGroup;
        this.name = name;
        this.levelOfDifficulty = levelOfDifficulty;
    }

    public String getMuscleGroup() {
        return muscleGroup;
    }

    public void setMuscleGroup(String muscleGroup) {
        this.muscleGroup = muscleGroup;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevelOfDifficulty() {
        return levelOfDifficulty;
    }

    public void setLevelOfDifficulty(int levelOfDifficulty) {
        this.levelOfDifficulty = levelOfDifficulty;
    }
}
