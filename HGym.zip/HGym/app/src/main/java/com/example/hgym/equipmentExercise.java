package com.example.hgym;

public class equipmentExercise extends exercise{
    protected double weight;

    public equipmentExercise() {
    }

    public equipmentExercise(String muscleGroup, String name, int levelOfDifficulty, double weight) {
        super(muscleGroup, name, levelOfDifficulty);
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
