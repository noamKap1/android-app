package com.example.hgym;

public class nonEquipmentExercise extends exercise{
    protected double duration;

    public nonEquipmentExercise() {
    }

    public nonEquipmentExercise(String muscleGroup, String name, int levelOfDifficulty, double duration) {
        super(muscleGroup, name, levelOfDifficulty);
        this.duration = duration;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }
}
